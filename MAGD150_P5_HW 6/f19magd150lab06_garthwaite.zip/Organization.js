var projectile;
var projectileX, projectileY;
var theta = 0.0;
var tankX, tankY;
var alienX, alienY; 
function setup() {
  createCanvas(400, 400);
  projectileX= 300;
  projectileY=350;
  projectile=false;
  tankX=285;
  tankY=350;
  alienX=width/2;
  alienY=height-350;
}

function draw() {
  background(0);

  drawAlien();
alienX=alienX+random(-10,10);
if(alienX > 400){
  alienX=25;
}else if(alienX<0){
  alienX=375;
}
  
 if(projectile){
   drawProjectile();
 }
  
  
  projectileY -=10;
  theta += 0.1;
  
  
  if (projectileY<=-5){
    projectileY=-15;
  }
 
  drawTank(tankX, tankY);
 
}


function drawTank(x,y){
  
  push();
  fill(0,255,0);
  noStroke();
  rect( x, y, 25, 25);
  rect(x-25, y+25, 75, 25);
  pop();
}

function keyPressed(){
  
  switch(keyCode){
      
    case LEFT_ARROW:
      tankX -=10;
      projectileX-=10;
      break;
      
      case RIGHT_ARROW:
      tankX +=10;
      projectileX+=10;
      break;
      
      case CONTROL:
      projectile = !projectile;
      projectileY= 350;
      break;
  }

  
  
}
   
function drawProjectile(){
    
 push();
  translate(projectileX, projectileY);
  rotate(theta);
  fill(255);
  rect(0,0,10,10);
  pop();
}
  function drawAlien(){
    push();
    noStroke();
    fill(255,0,0);
    rect(alienX,alienY,50,50);
    rect(alienX+50,alienY-25,25,25);
    rect(alienX-25,alienY-25,25,25);
    rect(alienX+50,alienY+50,25,25);
    rect(alienX-25,alienY+50,25,25);
    pop();

  } 


