
let Clown;
let ClownBomb;
let enemey;
let projectile;
let projectileX
let projectileY;
let DeadEnemey;
let ToastP;
let ToastPX;
let Boss;
levels [];
MainCharacter [];
 //declairing the varibles

function preload(){// loads outside filies

MainCharacter []=loadImage('');
Clown=loadImage('');
food=loadImage('');
ClownBomb=loadImage('');
enemey=loadImage('');
projectile=loadImage('');
DeadEnemey=loadImage('');
ToastP=loadImage('');
Boss=loadImage('');
levels[]=loadImage('');


function setup() {
  // put setup code here
  CreateCanvas(1000,500);
  projectile=false;
  projectileX=
  projectileY=


}

function draw() {
  // put drawing code here
translate(0,0);
MainCharacter.resize( , );// resizes and draws the loaded image 
image(MainCharacter[],0,0);

   if(projectile){// continal boolean that only calls my drawProjectile function if CONTROL is pressed acts as toggle
   drawProjectile();
 }
  projectile -=10;//sets the speed and rotation of projectile 
}

function keyPressed(){// function that allows tank movement and firing of projectile
  
  switch(keyCode){
      
    case LEFT_ARROW:
      MainCharacterX -=10;
      projectileX-=10;
      break;
      
      case RIGHT_ARROW:
      MainCharacterX +=10;
      projectileX+=10;
      break;
      
      case CONTROL:
      projectile = !projectile;
      projectileY= 350;
      break;
  } 